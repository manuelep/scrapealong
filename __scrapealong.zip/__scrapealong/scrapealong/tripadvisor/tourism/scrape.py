# -*- coding: utf-8 -*-

import json
import re
import uuid
from tqdm import tqdm
from price_parser import Price
from decimal import Decimal
import traceback
from ... common import logger
from ... helpers import Accumulator
from ..scrape import pagination as pagination
from itertools import zip_longest

AMENITY = 'tourism'

def pagination_(pages):
    """ """
    offset_=[int(x.text) for x in pages if int(x.text)!=0]
    total_offset=offset_[-1]/offset_[0]
    return total_offset

def pagination(response):
    """ """
    pages=response.findAll("a",{"class":re.compile(r'pageNum')})
    return pagination_(pages)

def collection(response):
    """ """
    hotels_=response.findAll("div",{"class":"_25PvF8uO _2X44Y8hm"})

    infos = []
    for hotel in tqdm(hotels_,total=len(hotels_)):
        info = {'amenity': AMENITY}

        url_=hotel.find("a",{"class":"_1QKQOve4"})
        if not url_ is None:
            url='https://www.tripadvisor.com'+url_['href']
            info['url'] = url

        if not url is None:
            try:
                sid=re.sub(r'[^0-9\.]', '', url.split("-")[2])
            except:
                sid=str(uuid.uuid4().fields[-1])[:51]
            else:
                info['sid'] = sid

        name_=hotel.find("a",{"class":"_1QKQOve4"})
        if not name_ is None:
            name=name_.text
            info['name'] = name

        star_=hotel.find("svg",{"class":"_3KcXyP0F"})
        if not star_ is None:
            info['stars:raw'] = star_['title'][:3]
            try:
                # star=re.sub(r'[^0-9\.]', '', star_['title'][:3])
                star=float(re.search('[0-9/.]+', star_['title'][:3]).group())
                info['stars:norm']=star/5.0
            except:
                info['stars:norm'] = 0.0
                pass
        else:
            info['stars:raw'] = 0.0
            info['stars:norm'] = 0.0


        review_count_=hotel.find("span",{"class":"HLvj7Lh5 _1L-8ZIjh _2s3pPhGm"})
        if not review_count_ is None:
            try:
                review_count=re.sub('[^0-9]', '', review_count_.text)
                info['reviews']=review_count
                info['views'] = review_count * 4
            except:
                info['reviews']=0
                info['views'] = 0
                pass
        else:
            info['reviews']=0
            info['views'] = 0

        try:
            tourism_type=hotel.find("span",{"class":"_21qUqkJx"}).text
            info['tourism:type']=tourism_type
        except:
            info['tourism:type']="Sights & Landmarks"

        # TODO: Implement here the calculation of other parameters useful for rating

        infos.append(info)

    return infos

def details(response,link):

    info = Accumulator()
    warnings = []

    sid_errors, sid_tbs = [], []

    try:
        sid=re.sub(r'[^0-9\.]', '', link.split("-")[2])
    except:
        sid=str(uuid.uuid4().fields[-1])[:51]
    else:
        info['sid'] = sid

    try:
        detail_type=response.find("a",{"class":"_1cn4vjE4"}).text
        info['detail:type'] = detail_type
    except:
        pass

    try:
        rank=response.find("div",{"class":"eQSJNhO6"}).text
        rank=re.search(r'[^a-zA-Z]*', rank)[0].strip()
        rank=re.sub(r'[^0-9]', '', rank)
        info['rank']=rank
    except:
        pass

    # TODO: Implement here the calculation of other parameters useful for rating
    try:
        columns = response.find('script', text = re.compile("""typeahead.recentHistoryList"""), attrs = {"type":"text/javascript"})
        r1=re.findall(r"taStore\.store\('typeahead\.recentHistoryList'.*",str(columns))
        r2=r1[0].replace("taStore.store('typeahead.recentHistoryList', ",'')
        r2=r2[:-2]
        ss=json.loads(r2)
        coords=[]
        [coords.append(x['coords']) for x in ss if "https://www.tripadvisor.com"+x['url']==link]
        lon_lat=tuple(map(float,coords[0].split(",")))[::-1]
    except Exception as err:
        sid_errors.append(err)
        sid_tbs.append(traceback.format_exc())
        lon_lat = None
    # import pdb;pdb.set_trace();

    return sid, lon_lat, info, warnings,
