# -*- coding: utf-8 -*-

from ..settings import *

SOURCE_NAME = 'tripadvisor'

BASE_URL = 'https://www.tripadvisor.com'
