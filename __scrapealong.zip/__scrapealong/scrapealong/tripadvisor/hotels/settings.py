# -*- coding: utf-8 -*-

from ...settings import *

from ..settings import *

TRACKED_LOCATIONS = TRIPADVISOR_HOTES_LOCATIONS

# # try import private settings
# try:
#     from .settings_private import *
# except:
#     pass
