IMMOBILIARE_LOCATIONS = [
    # Examples
    # "Torino",
    # "Genova",
    # "Rapallo",
    # "Santa Margherita Ligure",
    # "Milano"
]
TRIPADVISOR_HOTES_LOCATIONS = [
    # Examples
    'Hotels-g187826-Rapallo_Italian_Riviera_Liguria-Hotels.html',
]

TRIPADVISOR_RESTAURANTS_LOCATIONS = [
    # Examples
    'Restaurants-g187826-Rapallo_Italian_Riviera_Liguria.html',
]

TRIPADVISOR_TOURISM_LOCATIONS = [
    'Attractions-g187826-Activities-oa30-Rapallo_Italian_Riviera_Liguria.html',
    # 'Attractions-g187849-Activities-oa30-Milan_Lombardy.html'
]
